from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from models import Class, Lesson, Attendance, Collection, User
from datetime import datetime, timedelta

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@login_required
def index():
    user_class = current_user.class_rel
    
    # Get recent lessons
    recent_lessons = Lesson.query.filter_by(class_id=user_class.id)\
        .filter(Lesson.date >= datetime.now().date())\
        .order_by(Lesson.date, Lesson.start_time)\
        .limit(5).all() if user_class else []
    
    # Get attendance statistics
    if current_user.role in ['teacher', 'starosta', 'admin']:
        total_students = len([user for user in user_class.users if user.role == 'student']) if user_class else 0
        recent_attendance = Attendance.query.join(Lesson)\
            .filter(Lesson.class_id == user_class.id)\
            .order_by(Attendance.date.desc())\
            .limit(10).all() if user_class else []
        
        # Calculate attendance percentage
        total_lessons = Lesson.query.filter_by(class_id=user_class.id).count() if user_class else 0
        present_count = Attendance.query.join(Lesson)\
            .filter(Lesson.class_id == user_class.id, Attendance.status == 'present').count() if user_class else 0
        attendance_percentage = (present_count / (total_lessons * total_students) * 100) if total_lessons * total_students > 0 else 0
    else:
        # Student view
        total_students = 0
        recent_attendance = Attendance.query.filter_by(student_id=current_user.id)\
            .order_by(Attendance.date.desc())\
            .limit(10).all()
        
        # Student attendance percentage
        total_lessons = Lesson.query.filter_by(class_id=user_class.id).count() if user_class else 0
        present_count = Attendance.query.filter_by(student_id=current_user.id, status='present').count()
        attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
    
    # Get active collections
    active_collections = Collection.query.filter_by(class_id=user_class.id)\
        .filter(Collection.end_date >= datetime.now().date())\
        .order_by(Collection.end_date).all() if user_class else []
    
    return render_template('dashboard/index.html',
                         recent_lessons=recent_lessons,
                         total_students=total_students,
                         recent_attendance=recent_attendance,
                         active_collections=active_collections,
                         attendance_percentage=round(attendance_percentage, 1),
                         total_lessons=total_lessons)

@dashboard_bp.route('/stats')
@login_required
def stats():
    user_class = current_user.class_rel
    if not user_class:
        return jsonify({'error': 'No class found'}), 404
    
    # Calculate attendance percentage
    total_lessons = Lesson.query.filter_by(class_id=user_class.id).count()
    
    if current_user.role == 'student':
        present_count = Attendance.query.filter_by(
            student_id=current_user.id,
            status='present'
        ).count()
        attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
    else:
        # For teachers/admins, calculate class average
        students = [user for user in user_class.users if user.role == 'student']
        total_possible_attendance = total_lessons * len(students)
        total_present = Attendance.query.filter_by(status='present')\
            .join(User).filter(User.class_id == user_class.id).count()
        attendance_percentage = (total_present / total_possible_attendance * 100) if total_possible_attendance > 0 else 0
    
    return jsonify({
        'total_students': len([user for user in user_class.users if user.role == 'student']),
        'attendance_percentage': round(attendance_percentage, 1),
        'completed_lessons': total_lessons,
        'active_collections': Collection.query.filter_by(class_id=user_class.id)
                            .filter(Collection.end_date >= datetime.now().date()).count()
    })