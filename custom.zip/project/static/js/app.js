// Global JavaScript for Classwork platform

document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Enable tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Enable popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Confirmations for destructive actions
    const confirmLinks = document.querySelectorAll('a[data-confirm], button[data-confirm]');
    confirmLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Auto-submit forms on change
    const autoSubmitForms = document.querySelectorAll('form[data-auto-submit]');
    autoSubmitForms.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('change', function() {
                form.submit();
            });
        });
    });

    // Dynamic progress bars
    const progressBars = document.querySelectorAll('.progress-bar[data-width]');
    progressBars.forEach(bar => {
        const width = bar.getAttribute('data-width');
        bar.style.width = width + '%';
        bar.setAttribute('aria-valuenow', width);
    });

    // Search functionality
    const searchInputs = document.querySelectorAll('input[data-search]');
    searchInputs.forEach(input => {
        input.addEventListener('input', ClassworkUtils.debounce(function() {
            const searchTerm = this.value.toLowerCase();
            const target = this.getAttribute('data-search');
            const items = document.querySelectorAll(target);
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }, 300));
    });

    // Theme switcher
    const themeSwitch = document.querySelector('#themeSwitch');
    if (themeSwitch) {
        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        themeSwitch.checked = savedTheme === 'dark';

        themeSwitch.addEventListener('change', function() {
            const theme = this.checked ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
            
            // Update theme in backend if user is logged in
            if (window.currentUser) {
                fetch('/settings/theme', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ theme: theme })
                });
            }
        });
    }
});

// API functions
const ClassworkAPI = {
    // Attendance
    markAttendance: async function(lessonId, status) {
        try {
            const response = await fetch(`/schedule/api/attendance/${lessonId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: status })
            });
            
            if (response.ok) {
                return await response.json();
            } else {
                throw new Error('Failed to mark attendance');
            }
        } catch (error) {
            console.error('Error marking attendance:', error);
            throw error;
        }
    },

    // Bulk attendance
    bulkAttendance: async function(lessonId, attendanceData) {
        try {
            const response = await fetch('/attendance/bulk', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken()
                },
                body: JSON.stringify({
                    lesson_id: lessonId,
                    attendance: attendanceData
                })
            });
            
            if (response.ok) {
                return await response.json();
            } else {
                throw new Error('Failed to update bulk attendance');
            }
        } catch (error) {
            console.error('Error updating bulk attendance:', error);
            throw error;
        }
    },

    // Get statistics
    getStats: async function(endpoint) {
        try {
            const response = await fetch(endpoint);
            if (response.ok) {
                return await response.json();
            } else {
                throw new Error('Failed to fetch statistics');
            }
        } catch (error) {
            console.error('Error fetching statistics:', error);
            throw error;
        }
    },

    // Update user settings
    updateSettings: async function(settings) {
        try {
            const response = await fetch('/settings/api/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCSRFToken()
                },
                body: JSON.stringify(settings)
            });
            
            if (response.ok) {
                return await response.json();
            } else {
                throw new Error('Failed to update settings');
            }
        } catch (error) {
            console.error('Error updating settings:', error);
            throw error;
        }
    }
};

// Utility functions
const ClassworkUtils = {
    formatDate: function(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU');
    },
    
    formatTime: function(timeString) {
        const time = new Date(`1970-01-01T${timeString}`);
        return time.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    },
    
    formatDateTime: function(dateTimeString) {
        const date = new Date(dateTimeString);
        return date.toLocaleString('ru-RU');
    },
    
    formatCurrency: function(amount) {
        return new Intl.NumberFormat('ru-RU', {
            style: 'currency',
            currency: 'RUB'
        }).format(amount);
    },
    
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    showLoading: function(element) {
        element.innerHTML = '<div class="loading-spinner"></div>';
        element.disabled = true;
    },
    
    hideLoading: function(element, originalText) {
        element.innerHTML = originalText;
        element.disabled = false;
    },
    
    showNotification: function(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show`;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Add to page
        const container = document.querySelector('.container') || document.body;
        container.insertBefore(notification, container.firstChild);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }
};

// CSRF token helper
function getCSRFToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ClassworkAPI, ClassworkUtils };
}