from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import db, Lesson, Class, Attendance
from forms import LessonForm
from datetime import datetime, date

schedule_bp = Blueprint('schedule', __name__)

@schedule_bp.route('/')
@login_required
def index():
    user_class = current_user.class_rel
    if not user_class:
        return render_template('schedule/index.html', lessons=[])
    
    # Get lessons for the current month
    today = datetime.now().date()
    start_of_month = today.replace(day=1)
    if today.month == 12:
        end_of_month = today.replace(year=today.year + 1, month=1, day=1)
    else:
        end_of_month = today.replace(month=today.month + 1, day=1)
    
    lessons = Lesson.query.filter_by(class_id=user_class.id)\
        .filter(Lesson.date >= start_of_month, Lesson.date < end_of_month)\
        .order_by(Lesson.date, Lesson.start_time).all()
    
    # Get attendance for current user if student
    user_attendance = {}
    if current_user.role == 'student':
        for lesson in lessons:
            attendance = Attendance.query.filter_by(
                student_id=current_user.id,
                lesson_id=lesson.id
            ).first()
            user_attendance[lesson.id] = attendance.status if attendance else 'unknown'
    
    return render_template('schedule/index.html', 
                         lessons=lessons, 
                         user_attendance=user_attendance,
                         today=today)

@schedule_bp.route('/calendar')
@login_required
def calendar():
    return render_template('schedule/calendar.html')

@schedule_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_lesson():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('schedule.index'))
    
    form = LessonForm()
    
    if form.validate_on_submit():
        lesson = Lesson(
            subject=form.subject.data,
            date=form.date.data,
            start_time=form.start_time.data,
            end_time=form.end_time.data,
            description=form.description.data,
            class_id=current_user.class_rel.id
        )
        
        db.session.add(lesson)
        db.session.commit()
        flash('Урок успешно добавлен!', 'success')
        return redirect(url_for('schedule.index'))
    
    return render_template('schedule/form.html', form=form, action='add')

@schedule_bp.route('/lesson/<int:lesson_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_lesson(lesson_id):
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('schedule.index'))
    
    lesson = Lesson.query.get_or_404(lesson_id)
    
    # Check if lesson belongs to user's class
    if lesson.class_id != current_user.class_rel.id:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('schedule.index'))
    
    form = LessonForm()
    
    if form.validate_on_submit():
        lesson.subject = form.subject.data
        lesson.date = form.date.data
        lesson.start_time = form.start_time.data
        lesson.end_time = form.end_time.data
        lesson.description = form.description.data
        
        db.session.commit()
        flash('Урок успешно обновлен!', 'success')
        return redirect(url_for('schedule.index'))
    
    elif request.method == 'GET':
        form.subject.data = lesson.subject
        form.date.data = lesson.date
        form.start_time.data = lesson.start_time
        form.end_time.data = lesson.end_time
        form.description.data = lesson.description
    
    return render_template('schedule/form.html', form=form, action='edit', lesson=lesson)

@schedule_bp.route('/lesson/<int:lesson_id>/delete', methods=['POST'])
@login_required
def delete_lesson(lesson_id):
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('schedule.index'))
    
    lesson = Lesson.query.get_or_404(lesson_id)
    
    # Check if lesson belongs to user's class
    if lesson.class_id != current_user.class_rel.id:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('schedule.index'))
    
    db.session.delete(lesson)
    db.session.commit()
    flash('Урок успешно удален!', 'success')
    return redirect(url_for('schedule.index'))

@schedule_bp.route('/api/events')
@login_required
def api_events():
    user_class = current_user.class_rel
    if not user_class:
        return jsonify([])
    
    lessons = Lesson.query.filter_by(class_id=user_class.id).all()
    events = []
    
    for lesson in lessons:
        events.append({
            'id': lesson.id,
            'title': lesson.subject,
            'start': f"{lesson.date.isoformat()}T{lesson.start_time.isoformat()}",
            'end': f"{lesson.date.isoformat()}T{lesson.end_time.isoformat()}",
            'description': lesson.description,
            'className': 'lesson-event'
        })
    
    return jsonify(events)

@schedule_bp.route('/api/attendance/<int:lesson_id>', methods=['POST'])
@login_required
def mark_attendance(lesson_id):
    if current_user.role != 'student':
        return jsonify({'error': 'Only students can mark attendance'}), 403
    
    lesson = Lesson.query.get_or_404(lesson_id)
    status = request.json.get('status')
    
    if status not in ['present', 'absent', 'late']:
        return jsonify({'error': 'Invalid status'}), 400
    
    # Check if attendance already exists
    attendance = Attendance.query.filter_by(
        student_id=current_user.id,
        lesson_id=lesson_id
    ).first()
    
    if attendance:
        attendance.status = status
        attendance.date = date.today()
    else:
        attendance = Attendance(
            student_id=current_user.id,
            lesson_id=lesson_id,
            date=date.today(),
            status=status
        )
        db.session.add(attendance)
    
    db.session.commit()
    return jsonify({'message': 'Attendance marked successfully'})