from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from models import db, Attendance, Lesson, User
from forms import AttendanceForm
from datetime import datetime, date, timedelta

attendance_bp = Blueprint('attendance', __name__)

@attendance_bp.route('/')
@login_required
def index():
    user_class = current_user.class_rel
    if not user_class:
        return render_template('attendance/index.html', attendance_records=[])
    
    # Date filter
    date_filter = request.args.get('date')
    if date_filter:
        try:
            filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
        except ValueError:
            filter_date = date.today()
    else:
        filter_date = date.today()
    
    if current_user.role in ['teacher', 'starosta', 'admin']:
        # For teachers and starostas, show all attendance for their class
        attendance_records = Attendance.query.join(Lesson)\
            .filter(Lesson.class_id == user_class.id)\
            .filter(Attendance.date == filter_date)\
            .order_by(Attendance.date.desc())\
            .all()
        
        # Get all students for the class
        students = User.query.filter_by(class_id=user_class.id, role='student').all()
        
        # Create attendance matrix
        lessons_today = Lesson.query.filter_by(class_id=user_class.id)\
            .filter(Lesson.date == filter_date)\
            .order_by(Lesson.start_time).all()
        
        attendance_matrix = []
        for student in students:
            student_attendance = []
            for lesson in lessons_today:
                attendance = Attendance.query.filter_by(
                    student_id=student.id,
                    lesson_id=lesson.id
                ).first()
                student_attendance.append({
                    'lesson': lesson,
                    'attendance': attendance
                })
            attendance_matrix.append({
                'student': student,
                'attendance': student_attendance
            })
        
        return render_template('attendance/tracking.html',
                            attendance_matrix=attendance_matrix,
                            lessons_today=lessons_today,
                            filter_date=filter_date)
    else:
        # For students, show only their attendance
        attendance_records = Attendance.query.filter_by(student_id=current_user.id)\
            .filter(Attendance.date == filter_date)\
            .order_by(Attendance.date.desc())\
            .all()
    
    return render_template('attendance/index.html', 
                         attendance_records=attendance_records,
                         filter_date=filter_date)

@attendance_bp.route('/mark', methods=['GET', 'POST'])
@login_required
def mark_attendance():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        flash('Доступ запрещен.', 'error')
        return redirect(url_for('attendance.index'))
    
    form = AttendanceForm()
    
    # Populate student and lesson choices
    user_class = current_user.class_rel
    form.student_id.choices = [(s.id, s.full_name) for s in user_class.users if s.role == 'student']
    
    # Only show today's lessons
    today_lessons = Lesson.query.filter_by(class_id=user_class.id)\
        .filter(Lesson.date == date.today()).all()
    form.lesson_id.choices = [(l.id, f"{l.subject} ({l.start_time.strftime('%H:%M')})") for l in today_lessons]
    
    if form.validate_on_submit():
        # Check if attendance already exists for this student and lesson
        existing = Attendance.query.filter_by(
            student_id=form.student_id.data,
            lesson_id=form.lesson_id.data
        ).first()
        
        if existing:
            existing.status = form.status.data
            existing.notes = form.notes.data
            flash('Посещаемость обновлена!', 'success')
        else:
            attendance = Attendance(
                student_id=form.student_id.data,
                lesson_id=form.lesson_id.data,
                date=date.today(),
                status=form.status.data,
                notes=form.notes.data
            )
            db.session.add(attendance)
            flash('Посещаемость успешно отмечена!', 'success')
        
        db.session.commit()
        return redirect(url_for('attendance.index'))
    
    return render_template('attendance/form.html', form=form)

@attendance_bp.route('/bulk', methods=['POST'])
@login_required
def bulk_attendance():
    if current_user.role not in ['teacher', 'starosta', 'admin']:
        return jsonify({'error': 'Доступ запрещен'}), 403
    
    data = request.get_json()
    lesson_id = data.get('lesson_id')
    attendance_data = data.get('attendance', {})
    
    lesson = Lesson.query.get_or_404(lesson_id)
    
    for student_id, status in attendance_data.items():
        attendance = Attendance.query.filter_by(
            student_id=student_id,
            lesson_id=lesson_id
        ).first()
        
        if attendance:
            attendance.status = status
            attendance.date = date.today()
        else:
            attendance = Attendance(
                student_id=student_id,
                lesson_id=lesson_id,
                date=date.today(),
                status=status
            )
            db.session.add(attendance)
    
    db.session.commit()
    return jsonify({'message': 'Посещаемость обновлена успешно!'})

@attendance_bp.route('/reports')
@login_required
def reports():
    user_class = current_user.class_rel
    if not user_class:
        return render_template('attendance/reports.html', stats={})
    
    # Date range filter
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date and end_date:
        try:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        except ValueError:
            start_date = date.today() - timedelta(days=30)
            end_date = date.today()
    else:
        start_date = date.today() - timedelta(days=30)
        end_date = date.today()
    
    if current_user.role in ['teacher', 'starosta', 'admin']:
        # Class report
        students = User.query.filter_by(class_id=user_class.id, role='student').all()
        lessons = Lesson.query.filter_by(class_id=user_class.id)\
            .filter(Lesson.date >= start_date, Lesson.date <= end_date).all()
        
        report_data = []
        for student in students:
            student_attendance = Attendance.query.filter_by(student_id=student.id)\
                .join(Lesson).filter(Lesson.date >= start_date, Lesson.date <= end_date).all()
            
            present_count = sum(1 for a in student_attendance if a.status == 'present')
            total_lessons = len(lessons)
            attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
            
            report_data.append({
                'student': student,
                'present_count': present_count,
                'total_lessons': total_lessons,
                'attendance_percentage': round(attendance_percentage, 1),
                'absences': total_lessons - present_count
            })
        
        return render_template('attendance/reports.html',
                            report_data=report_data,
                            start_date=start_date,
                            end_date=end_date,
                            total_lessons=len(lessons))
    else:
        # Student report
        lessons = Lesson.query.filter_by(class_id=user_class.id)\
            .filter(Lesson.date >= start_date, Lesson.date <= end_date).all()
        
        student_attendance = Attendance.query.filter_by(student_id=current_user.id)\
            .join(Lesson).filter(Lesson.date >= start_date, Lesson.date <= end_date).all()
        
        present_count = sum(1 for a in student_attendance if a.status == 'present')
        total_lessons = len(lessons)
        attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
        
        return render_template('attendance/reports.html',
                            present_count=present_count,
                            total_lessons=total_lessons,
                            attendance_percentage=round(attendance_percentage, 1),
                            start_date=start_date,
                            end_date=end_date)

@attendance_bp.route('/api/stats')
@login_required
def api_stats():
    user_class = current_user.class_rel
    if not user_class:
        return jsonify({'error': 'No class found'}), 404
    
    if current_user.role == 'student':
        total_lessons = Lesson.query.filter_by(class_id=user_class.id).count()
        present_count = Attendance.query.filter_by(
            student_id=current_user.id,
            status='present'
        ).count()
        attendance_percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
        
        return jsonify({
            'total_lessons': total_lessons,
            'present_count': present_count,
            'attendance_percentage': round(attendance_percentage, 1)
        })
    else:
        # For teachers, return class statistics
        students = [user for user in user_class.users if user.role == 'student']
        total_lessons = Lesson.query.filter_by(class_id=user_class.id).count()
        
        stats = []
        for student in students:
            present_count = Attendance.query.filter_by(
                student_id=student.id,
                status='present'
            ).count()
            percentage = (present_count / total_lessons * 100) if total_lessons > 0 else 0
            
            stats.append({
                'student_name': student.full_name,
                'present_count': present_count,
                'attendance_percentage': round(percentage, 1)
            })
        
        return jsonify(stats)