from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, DateField, TimeField, FloatField, SelectField, FileField, BooleanField, IntegerField, PasswordField
from wtforms.validators import DataRequired, Email, Length, Optional, NumberRange, EqualTo, ValidationError
from flask_wtf.file import FileAllowed
from models import User, Class
import re

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember = BooleanField('Запомнить меня')

class RegistrationForm(FlaskForm):
    full_name = StringField('Полное имя', validators=[DataRequired(), Length(max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[
        DataRequired(),
        Length(min=8, message='Пароль должен быть не менее 8 символов'),
    ])
    confirm_password = PasswordField('Подтвердите пароль', validators=[
        DataRequired(), 
        EqualTo('password', message='Пароли должны совпадать')
    ])
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data.lower()).first()
        if user:
            raise ValidationError('Этот email уже зарегистрирован')

class RequestResetForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data.lower()).first()
        if not user:
            raise ValidationError('Пользователь с таким email не найден')

class ResetPasswordForm(FlaskForm):
    password = PasswordField('Новый пароль', validators=[
        DataRequired(),
        Length(min=8, message='Пароль должен быть не менее 8 символов')
    ])
    confirm_password = PasswordField('Подтвердите пароль', validators=[
        DataRequired(), 
        EqualTo('password', message='Пароли должны совпадать')
    ])

class ClassForm(FlaskForm):
    name = StringField('Название класса', validators=[DataRequired(), Length(max=50)])
    description = TextAreaField('Описание', validators=[Optional()])
    class_logo = FileField('Логотип класса', validators=[Optional(), FileAllowed(['jpg', 'jpeg', 'png', 'gif'], 'Только изображения!')])

class LessonForm(FlaskForm):
    subject = StringField('Предмет', validators=[DataRequired(), Length(max=100)])
    date = DateField('Дата', validators=[DataRequired()], format='%Y-%m-%d')
    start_time = TimeField('Время начала', validators=[DataRequired()], format='%H:%M')
    end_time = TimeField('Время окончания', validators=[DataRequired()], format='%H:%M')
    description = TextAreaField('Описание', validators=[Optional()])
    
    def validate_end_time(self, end_time):
        if self.start_time.data and end_time.data:
            if end_time.data <= self.start_time.data:
                raise ValidationError('Время окончания должно быть позже времени начала')

class AttendanceForm(FlaskForm):
    student_id = SelectField('Студент', coerce=int, validators=[DataRequired()])
    lesson_id = SelectField('Урок', coerce=int, validators=[DataRequired()])
    status = SelectField('Статус', choices=[
        ('present', 'Присутствовал'),
        ('absent', 'Отсутствовал'),
        ('late', 'Опоздал'),
        ('dismissed_early', 'Ушел раньше')
    ], validators=[DataRequired()])
    notes = TextAreaField('Заметки', validators=[Optional()])

class CollectionForm(FlaskForm):
    name = StringField('Название сбора', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('Описание', validators=[Optional()])
    target_amount = FloatField('Целевая сумма', validators=[DataRequired(), NumberRange(min=0, message='Сумма должна быть положительной')])
    start_date = DateField('Дата начала', validators=[DataRequired()], format='%Y-%m-%d')
    end_date = DateField('Дата окончания', validators=[DataRequired()], format='%Y-%m-%d')
    collection_logo = FileField('Логотип сбора', validators=[Optional(), FileAllowed(['jpg', 'jpeg', 'png', 'gif'], 'Только изображения!')])
    
    def validate_end_date(self, end_date):
        if self.start_date.data and end_date.data:
            if end_date.data < self.start_date.data:
                raise ValidationError('Дата окончания должна быть позже даты начала')

class PaymentForm(FlaskForm):
    student_id = SelectField('Студент', coerce=int, validators=[DataRequired()])
    amount = FloatField('Сумма', validators=[DataRequired(), NumberRange(min=0, message='Сумма должна быть положительной')])
    status = SelectField('Статус', choices=[
        ('paid', 'Оплачено'),
        ('unpaid', 'Не оплачено'),
        ('partial', 'Частично')
    ], validators=[DataRequired()])
    notes = TextAreaField('Заметки', validators=[Optional()])

class InvitationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    role = SelectField('Роль', choices=[
        ('student', 'Студент'),
        ('starosta', 'Староста')
    ], validators=[DataRequired()])

class SettingsForm(FlaskForm):
    full_name = StringField('Полное имя', validators=[DataRequired(), Length(max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    language = SelectField('Язык', choices=[('ru', 'Русский'), ('en', 'English')])
    theme = SelectField('Тема', choices=[('light', 'Светлая'), ('dark', 'Темная')])
    notifications_enabled = BooleanField('Включить уведомления')

class UserSettingsForm(FlaskForm):
    email_notifications = BooleanField('Email уведомления')
    lesson_reminders = BooleanField('Напоминания об уроках')
    payment_reminders = BooleanField('Напоминания о платежах')
    attendance_alerts = BooleanField('Оповещения о посещаемости')
    items_per_page = SelectField('Элементов на странице', choices=[
        ('10', '10'), ('20', '20'), ('50', '50'), ('100', '100')
    ], coerce=int)
    compact_view = BooleanField('Компактный вид')

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Текущий пароль', validators=[DataRequired()])
    new_password = PasswordField('Новый пароль', validators=[
        DataRequired(),
        Length(min=8, message='Пароль должен быть не менее 8 символов')
    ])
    confirm_new_password = PasswordField('Подтвердите новый пароль', validators=[
        DataRequired(), 
        EqualTo('new_password', message='Пароли должны совпадать')
    ])

class AdminUserForm(FlaskForm):
    role = SelectField('Роль', choices=[
        ('admin', 'Администратор'),
        ('teacher', 'Учитель'),
        ('student', 'Студент'),
        ('starosta', 'Староста')
    ], validators=[DataRequired()])
    is_active = BooleanField('Активный аккаунт')
    class_id = SelectField('Класс', coerce=int, validators=[Optional()])
    
    def __init__(self, *args, **kwargs):
        super(AdminUserForm, self).__init__(*args, **kwargs)
        self.class_id.choices = [(0, 'Без класса')] + [
            (c.id, c.name) for c in Class.query.order_by(Class.name).all()
        ]